<template>
  <div class="page-scroll-detail">
    hello world
    <h1>{{id}}</h1>
    <p>测试1</p>
    <p>测试2</p>
    <p>测试3</p>
    <p>测试4</p>
    <p>测试5</p>
    <p>测试6</p>
    <p>测试7</p>
    <p>测试8</p>
    <p>测试9</p>
    <p>测试10</p>
    <p>测试11</p>
    <p>测试12</p>
    <p>测试13</p>
    <p>测试14</p>
    <p>测试15</p>
    <p>测试16</p>
    <p>测试17</p>
    <p>测试18</p>
    <p>测试19</p>
    <p>测试20</p>
    <p>测试21</p>
    <p>测试22</p>
    <p>测试23</p>
    <p>测试24</p>
    <p>测试25</p>
    <p>测试26</p>
    <p>测试27</p>
    <p>测试28</p>
    <p>测试29</p>
    <p>测试30</p>
    <p>测试31</p>
    <p>测试32</p>
    <p>测试33</p>
    <p>测试34</p>
    <p>测试35</p>
    <p>测试36</p>
    <p>测试37</p>
    <p>测试38</p>
    <p>测试39</p>
    <p>测试40</p>
    <p>测试41</p>
    <p>测试42</p>
    <p>测试43</p>
    <p>测试44</p>
    <p>测试45</p>
    <p>测试46</p>
    <p>测试47</p>
    <p>测试48</p>
    <p>测试49</p>
    <p>测试50</p>
  </div>
</template>

<style lang="scss" src="./scroll.scss"></style>

<script>
  // import axios from 'axios';

  export default {
    data() {
      return {
        id: ''
      };
    },
    computed: {},
    watch: {},
    methods: {},
    components: {},
    mounted() {
      this.id = this.$route.query.id;
      console.log(this);
    }
  }
</script>
