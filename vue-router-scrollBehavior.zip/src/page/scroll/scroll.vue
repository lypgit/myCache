<template>
    <div class="page-scroll">
      <ul>
        <li @click="toDetail(1)">这是第1个离别列表列表项</li>
        <li @click="toDetail(2)">这是第2个离别列表列表项</li>
        <li @click="toDetail(3)">这是第3个离别列表列表项</li>
        <li @click="toDetail(4)">这是第4个离别列表列表项</li>
        <li @click="toDetail(5)">这是第5个离别列表列表项</li>
        <li @click="toDetail(6)">这是第6个离别列表列表项</li>
        <li @click="toDetail(7)">这是第7个离别列表列表项</li>
        <li @click="toDetail(8)">这是第8个离别列表列表项</li>
        <li @click="toDetail(9)">这是第9个离别列表列表项</li>
        <li @click="toDetail(10)">这是第10个离别列表列表项</li>
        <li @click="toDetail(11)">这是第11个离别列表列表项</li>
        <li @click="toDetail(12)">这是第12个离别列表列表项</li>
        <li @click="toDetail(13)">这是第13个离别列表列表项</li>
        <li @click="toDetail(14)">这是第14个离别列表列表项</li>
        <li @click="toDetail(15)">这是第15个离别列表列表项</li>
        <li @click="toDetail(16)">这是第16个离别列表列表项</li>
        <li @click="toDetail(17)">这是第17个离别列表列表项</li>
        <li @click="toDetail(18)">这是第18个离别列表列表项</li>
        <li @click="toDetail(19)">这是第19个离别列表列表项</li>
        <li @click="toDetail(20)">这是第20个离别列表列表项</li>
        <li @click="toDetail(21)">这是第21个离别列表列表项</li>
        <li @click="toDetail(22)">这是第22个离别列表列表项</li>
        <li @click="toDetail(23)">这是第23个离别列表列表项</li>
        <li @click="toDetail(24)">这是第24个离别列表列表项</li>
        <li @click="toDetail(25)">这是第25个离别列表列表项</li>
        <li @click="toDetail(26)">这是第26个离别列表列表项</li>
        <li @click="toDetail(27)">这是第27个离别列表列表项</li>
        <li @click="toDetail(28)">这是第28个离别列表列表项</li>
        <li @click="toDetail(29)">这是第29个离别列表列表项</li>
        <li @click="toDetail(30)">这是第30个离别列表列表项</li>
      </ul>
    </div>
</template>

<style lang="scss" src="./scroll.scss"></style>

<script>
    // import axios from 'axios';
    import router from '../../router/index';

    export default {
        data() {
            return {};
        },
        computed: {},
        watch: {},
        methods: {
          toDetail(index){
            router.push({
              path:'/scrollDetail',
              query: {
                id: index
              }
            });
          }
        },
        components: {},
        mounted() {
            console.log(this);
        }
    }
</script>
