<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <textarea></textarea>
  </div>
</template>

<script>
export default {
  name: 'hello',
  data () {
    return {
      msg: '项目测试'
    }
  },
  mounted() {
    window.addEventListener('resize', function () {
      if (document.activeElement.tagName == 'INPUT' || document.activeElement.tagName == 'TEXTAREA') {
        window.setTimeout(function () {
          document.activeElement.scrollIntoViewIfNeeded();
          alert(1);
        }, 0);
      }
    });
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}

textarea {
  width: 80%;
  height: 60px;
}
</style>
