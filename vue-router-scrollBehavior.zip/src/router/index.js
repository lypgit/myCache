import Vue from 'vue'
import Router from 'vue-router'
import Hello from '@/components/Hello'
import scroll from '@/page/scroll/scroll'
import scrollDetail from '@/page/scroll/detail'

Vue.use(Router);

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Hello',
      component: Hello
    },
    {
      path: '/scroll',
      name: 'scroll',
      component: scroll,
      meta: {
        title: 'scroll',
        keepAlive: true
      }
    },
    {
      path: '/scrollDetail',
      name: 'scrollDetail',
      component: scrollDetail
    }
  ],
  history: true,
  scrollBehavior(to, from, savedPosition) {
    console.log('滚动1', to);
    console.log('滚动2', from);
    console.log('滚动3', savedPosition);
    if (savedPosition) {
      return savedPosition
    } else {
      if (from.meta.keepAlive) {
        from.meta.savedPosition = document.body.scrollTop;
      }
      return {x: 0, y: to.meta.savedPosition || 0}
    }
  }
})
